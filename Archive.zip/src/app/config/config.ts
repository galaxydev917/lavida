export const config = {
    // backend url
    Url: 'http://aligtesting.com',
    // api enpoint base url
    api_baseUrl: 'http://aligtesting.com/api/api_offlineapp',

    cart_products: 'cart_products',
    delivery_addressInfo: 'delivery_addressInfo',
    profileInfo: 'profileInfo'
};
